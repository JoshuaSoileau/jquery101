#Exercise 4
###Selectors in jQuery

1. Let's start making this legit. Let's take everything we did from the last exercise, and put it all in `scripts.js`. Take all of the `jQuery` you wrote for the last piece, and write it out so that it runs in `scripts.js`, and then fiddle (google) with it to get it running when your page loads. As a reminder, here's all the instructions from the previous exercise:
  	1. Open up the .html file in a web browser.
  	2. Open the browser's developer tools.
  	3. Guess what. I don't have a cat. I'm a dog person! Figure out how to change the `src` attribute of the `<img>` tag to `dog.jpg` instead of `cat.jpg`.
  	4. Other exercises TBD in class... including using wrapping and changing css...