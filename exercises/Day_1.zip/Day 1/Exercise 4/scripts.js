
// Answer:

// $(document).ready(function() {

//   $('.animal').text('dog');
//   $('.green:not(#hello) span').text('ferocious');

//   $('img').attr('src', 'dog.jpg').attr('width', '600');

// });


// Functions learned:
// $(document).ready(function() {

// });