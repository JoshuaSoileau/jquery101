#Exercise 1
###How to link jQuery to a web page.

1. Open up the .html file in a web browser. You'll notice that it says jQuery isn't linked.
2. Download the latest stable version of jQuery to your computer.
3. Link that file to the .html document.
4. Reload the document and show the instructors.

Instructions for Josh

1. Keep running list on board of jQuery functions we learn.
