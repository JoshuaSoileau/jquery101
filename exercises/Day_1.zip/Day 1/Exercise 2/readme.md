#Exercise 2
###Selectors in jQuery

1. Open up the .html file in a web browser.
2. Open the browser's developer tools.
	1. Figure out what the jQuery thing is.
	2. Open up that jQuery thing and look around. 
3. Use the console to grab:
	1. the `<body>` tag
	2. the `<head>` tag
	3. all of the `<p>` tags
4. Change the contents of the `#hello` tag to something more personable... Google it!!
5. Do other things TBD in class ... including addressing our odds of survival...

Instructions for Josh

1. Draw `DOM` on board & talk about it.
2. Talk about `jQuery` selectors, how they relate to CSS, and what they return (vs just plain ole' javascript).