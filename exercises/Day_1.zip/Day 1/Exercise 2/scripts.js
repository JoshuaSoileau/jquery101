// Answers:
// Run this code in the terminal to change the percentage from 0% to 25%
// $('.survival-percentage .red').text('25%');

// And now this code will change it to 75% and change the color to green
// $('.survival-percentage .red').html('25%').addClass('green').removeClass('red');


// Functions learned:
// .text()
// .html()
// .addClass()
// .removeClass()