#Exercise 5
###Events in jQuery

Okay so now we're legit. Ish. We have all our code running on page load using `$(document).ready()`. Let's add a little `Interactivity` into the mix.
It's time to learn about `Events`.

1. Add click event to `<body>` to alert a message.
2. Add another click event to `<p>` to alert another message.
3. Add hover events. What is the difference between `.on('hover', ...)` and `.hover()`? What is the difference in `.hover()` and `.mouseenter()`???
4. How many other types of events are out there?? What kind are there?