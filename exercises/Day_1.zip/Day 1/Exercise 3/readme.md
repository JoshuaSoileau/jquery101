#Exercise 3
###Selectors in jQuery

1. Open up the .html file in a web browser.
2. Open the browser's developer tools.
3. Guess what. I don't have a cat. I'm a dog person! Figure out how to change the `src` attribute of the `<img>` tag to `dog.jpg` instead of `cat.jpg`.
4. Other exercises TBD in class... including using wrapping and changing css...