// Answers:
// Run this code to change the 'src' attribute to something else
// $('img').attr('src', 'dog.jpg');

// This will change the span 'cat' to 'dog'
// $('.animal').text('dog');

// And this will change the word 'cute' to 'ferocious'
// $('.green span').text('ferocious');

// Functions Learned:
// .attr()