#Exercise 1
###Practice with Data and Functions.

Let's make some neat effects with the `.css()` function.

1. Create an array with a series of CSS color values.
2. Add a click event observer for all .box elements, changing the css background color of each to a different index of the array from step 1 each time you click it.
3. Change your click observer to a hover observer.

