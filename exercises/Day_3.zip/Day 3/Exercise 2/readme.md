#Exercise 2
###Building Accordians

Accordians are a common UI element on webpages, we're gonna build one. Should be simple enough, we're pros at this stuff by now.

1. Create a function that will hide all dropdown content when you click an `<li>`.
2. Change the function to then display only the dropdown content for the `<li>` that was clicked
3. Change the function to slide the elements down or up instead of just showing or hiding them.


Simple enough, you've just built an accordian!
